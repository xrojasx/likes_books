from __future__ import unicode_literals

from django.apps import AppConfig


class LikesBooksConfig(AppConfig):
    name = 'likes_books'
